
<?php 
  //include('db.php');
   include('data.php');

print_r ($_FILES);



    if( isset($_POST['user_submit']) == 'Register' ) {
    //second task

  
        $fullName       = $_POST['full_name']        ;// first kaj after making the form fields full_name from form's 'name' aita korar karon holo form er prottekta field er 'name' k variable er modhhe assign korbo.value dhorar jonno
        $eamilAddress   = $_POST['email_address']    ; 
        $userName       = $_POST['user_name']        ;
        $phoneNumber    = $_POST['phone_number']     ;
         $nid           = $_POST['nid']              ;
        $location       = $_POST['location']         ;
        $image_name   = $_FILES['photo']['name']     ;
       $reg            = $_POST['user_submit']      ; 
       

        //second task er por ai third task korte hobe
       
               //name="user_submit"         //value="Register"

          if(         $reg   ==        'Register'      )
           {
           

            if ( empty( $fullname ))  // ai $fullname holo second er variable gula
             {

              $error = 'Please enter your fullname';
        
            } 
      else if
( empty(  $eamilAddress  ) )
       {

   $error = 'Please enter your email address';

      } 
      else if 
            ( !filter_var(  $eamilAddress, FILTER_VALIDATE_EMAIL ) ) //for email validation
      { 

        $error = 'Please enter your valid email address';
      }
   else if   
      ( empty( $userName  ))
    {

      $error = 'Please enter your username';
        
    }
    else if 
     ( empty( $phoneNumber  ))
       {

       $error = 'Please enter your phone';
        
   } 
        else if ( empty( $nid  ))
         {

$error = 'Please enter your national Id';
        
      } 

     else if ( empty(  $location   )) {

       $error = 'Please enter your location';
        
     } 

else if ( empty( $image_name ) )
 {

        $error = 'Please select your profile picture';

      } else {
     

      //4th task file er kaj  (validation)

        $image_name   = $_FILES['photo']['name'];  // ai 'photo' holo form er 'name' theke neya
        $image_tmp_name = $_FILES['photo']['tmp_name'];
        $image_type   = $_FILES['photo']['type'];
        $image_size   = $_FILES['photo']['size'];
      //5th folder create kore oi folder image ta rakbo r folder ta ekta variable er modhhe niye nibo
        $directory ='profile_picture/';

       //6th
        $unique_image = time().$image_name;//eta holo jata image replace na hoye jotogula image upload kora hobe shobgula jeno folder e joma hoi.nahole khali repalce hoye just ekta photo e thakbe folder e




          //7th image upload er function r validation

        if ( empty( $image_name )) 
        {
          $error = 'Please select your photo';
        } 
        else if( $image_size > 57926 )
         {
          $error = 'Please select your photo less than 1MB';
        } 
        else
        {
                            //filename   // destination
       move_uploaded_file($image_tmp_name, $directory.$unique_image );
         }
 

           //8th work
             $picture = $directory.$unique_image;

      //if( !empty($fullName) && !empty($eamilAddress) && !empty($userName) && !empty($phoneNumber) && !empty($nid )
       // && !empty($location))


         

          // 9th database er kaj
        //insert into er gula ashche holo database er attribute er namnegula theke
        $sql = "INSERT INTO fullpage (full_name,email,user_name,phone_number,nid,location,image) 

          VALUES('$fullName','$eamilAddress','$userName','$phoneNumber',' $nid ',' $location ', '$picture')";  //'picture ' ashche holo   [$picture = $dir.$unique_image;] aita theke

        //   values er gula ashche holo second task er variable gula      





          //after filling up the form one of these messages will show

         
          if(  $db->query($sql) ) {
           $error= "DATA INSERT SUCCESSFULLY";
          } else{
           $error = "PLEASE TRY AGAIN LATER";
          }
} 



}

}


?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>registration page</title>

    <!-- icon on tab integration -->
    <link rel="icon" href="" type="image/x-icon">

    <!-- Bootstrap integration -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">


    <!-- Boiler integration -->
    <link rel="stylesheet" href="text/css" href="css/normalize.css">
    <link rel="stylesheet" href="text/css" href="css/main.css">
    <script src="js/modernizr-3.6.0.min.js"></script>

<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/style.css">


</head>

<body>

  <!-- body starts -->

<!-- navbar starts -->


 <!-- body starts -->



<!-- form starts -->



<div class="container form-area">
    <div class="row margin">
        <div class="col-md-2 col-sm-2"></div>

        <div class="col-md-8 col-sm-8 col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading form-heading"> Fill up the form  <span style="color:red;"></span></div>
                   
                    <div class="panel-body">

                   <!-- form er head-->
                     <form class="form-horizontal" action="" method="POST"  enctype="multipart/form-data"  >
                                   <!-- file upload er jonno encttype ta add kora hoise r method ta post method ei rakbo-->


                                   <!-- form er field banono sesh hoye gele 'second task' e chole jabo -->


          
      
                              
                          <div class="form-group">
                            <label for="Full Name" class="col-sm-4 control-label">Full Name</label>
                            <div class="col-sm-6">
                              <input type="text" name="full_name" class="form-control" id="full-name" placeholder=""  required>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="E-Mail Address" class="col-sm-4 control-label">E-Mail Address</label>
                            <div class="col-sm-6">
                              <input type="email" name="email_address" class="form-control" id="email-address" placeholder=""  required  >
                            </div>
                          </div>
                          
                          <div class="form-group">
                         
                            <label for="User Name" class="col-sm-4 control-label">User Name</label>
                            <div class="col-sm-6">
                              <input type="text" name="user_name" class="form-control" id="user-name" placeholder="">
                            </div>
                             
                          </div>

                          <div class="form-group">
                            <label for="Phone Number" class="col-sm-4 control-label">Phone Number</label>
                            <div class="col-sm-6">
                              <input type="text" name="phone_number" class="form-control" id="phone-number" placeholder="">
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="NID" class="col-sm-4 control-label">NID</label>
                            <div class="col-sm-6">
                              <input type="text" name="nid" class="form-control" id="nid" placeholder="">
                            </div>
                          </div>


                          <div class="form-group">
                            <label for="Location" class="col-sm-4 control-label">Location</label>
                            <div class="col-sm-6">
                              <input type="text" name="location" class="form-control" id="location" placeholder="">
                            </div>
                          </div>


                        <div class="form-group">
                            <label for="file" class="col-sm-4 control-label">Upload image</label>
                            <div class="col-sm-6">
                              <input type="file" name="photo" class="form-control" id="photo" placeholder="">
                            </div>
                          </div>



						  
                          <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-10">
							  <!-- <button type="submit" name="" class="btn btn-primary mybtn">Register</button> -->
                				<input type="submit" name="user_submit" class="btn btn-primary mybtn" value="Register">
                
                            </div>
						  </div>
						  
                        </form>


                  <!-- form ends -->

 <!-- table -->


<table class="table">

          <tr>
            <th>Full Name</th>
        <!--    <th>Email</th>
               <th>User Name</th>
            <th>Phone Number</th>
            <th>NID</th>  -->
            <th>About</th>

          </tr>         
          <?php         
            $query = "SELECT * FROM fullpage";
            $result = $db->query($query);

            // echo $result->num_rows;
            if( $result->num_rows > 0 ) {
              
              while ($data = $result->fetch_assoc()) 
                { ?>
                <tr>
                  <td> <?php echo $data['full_name'];?></td> 
                  <td><a href="details.php?userId=<?php echo $data['id'];?>">View Details</a></td>
               
                </tr>
            <?php    
            } 
            }
            
             else {
              echo "No Data Found";
            }           
          
        ?>
        </table>


 <!-- table -->

<!--    body ends-->




    <!--    Bootstrap integrtaion for js file-->
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>


    <!--    html5 boilerplate integration for js-->
    <script src="js/plugins.js"></script>
	<script src="js/main.js"></script>
	

	<script>

   
		//function checkEmptyData() {

			 
			//var fullname 		  = document.getElementById('full-name').value;
			//var emailAddress 	= document.getElementById('email-address').value;
//var username 		  = document.getElementById('user-name').value;
     // var phone         = document.getElementById('phone-number').value;
//var nid           = document.getElementById('nid').value;
     // var location      = document.getElementById('location').value;
 
      

			//if (fullname == '' ) {
			//	alert('Full name Empty');
//return false;
		//	} else if( emailAddress == '' ) {
		//		alert('Email address is emapty');
 //return false;
	//		} else if ( username == '' ) {
			//	alert('Username is Empty');
			//	return false;
			//}




//if (phone == '' ) {
      //  alert('phone number is Empty');
       // return false;
      //} else if( nid == '' ) {
      //  alert('nid is mandatory');
       // return false;
    //  } else if ( location == '' ) {
//alert('write your location');
    //    return false;
    //  }
			
	//	}           

	</script>  
</body>

</html>