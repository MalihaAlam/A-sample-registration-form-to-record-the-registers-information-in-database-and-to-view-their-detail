<?php
 
 //  database connection
    $servername = 'localhost';
    $username   = 'root';
    $password   = '';
    $database   = 'profile';

    $db = new mysqli($servername,$username,$password,$database);
//for checking whether the database has been connected or not
    if( $db->connect_error ) {
        die($db->connect_error);
    }


?>