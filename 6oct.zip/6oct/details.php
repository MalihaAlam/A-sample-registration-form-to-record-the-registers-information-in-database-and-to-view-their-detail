<?php 
  //include('one.php');
   include('data.php');

   ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>
		Full INFORMATION
	</title>
</head>
<body>
<?php 
       if(isset($_GET['userId']))
       {
       $userId = $_GET['userId']  ;

     $sql="SELECT * FROM fullpage WHERE id = '$userId' ";
      $userData = $db->query($sql); 

      //print_r($userData);

       $SingleUser = mysqli_fetch_assoc($userData);
    }
    
?>


       <h2>Name :<?php echo $SingleUser['full_name'] ;?></h2>  <!-- full_name is from database table -->
      <h2>Email Address :<?php echo $SingleUser['email'] ;?></h2>
    <h2>Username :<?php echo $SingleUser['user_name'] ;?></h2>
    <h2>Phone Number :<?php echo $SingleUser['phone_number'] ;?></h2>
    <h2>NID :<?php echo $SingleUser['nid'] ;?></h2>
    <h2>Location :<?php echo $SingleUser['location'] ;?></h2>

<h2>image :<?php echo $SingleUser['image'] ;?></h2>






				</body>

</html>